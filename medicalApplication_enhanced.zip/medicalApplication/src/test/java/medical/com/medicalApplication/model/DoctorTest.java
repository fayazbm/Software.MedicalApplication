package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DoctorTest {
	Doctor doctor;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		doctor = new Doctor("testdoc1", "doc1id1234");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Doctor#getName()}.
	 */
	@Test
	public void testGetName() {
		assertEquals( "testdoc1", doctor.getName());
	
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Doctor#setName(java.lang.String)}.
	 */
	@Test
	public void testSetName() {
		doctor.setName("testdoc2");
		assertEquals("testdoc2", doctor.getName());

	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Doctor#getId()}.
	 */
	@Test
	public void testGetId() {
		assertEquals("doc1id1234", doctor.getId());
	
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Doctor#setId(java.lang.String)}.
	 */
	@Test
	public void testSetId() {
		doctor.setId("doc2id5678");
		assertEquals("doc2id5678", doctor.getId());
	
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Doctor#toString()}.
	 */
	@Test
	public void testToString() {
		assertEquals("Doctor Name:testdoc1 ID: doc1id1234", doctor.toString());
	}


}

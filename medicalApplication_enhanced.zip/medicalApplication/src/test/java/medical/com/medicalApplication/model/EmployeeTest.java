package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class EmployeeTest {

	/**
	 * @throws java.lang.Exception
	 */
	Employee employee;
	
	@Before
	public void setUp() throws Exception {
		employee = new Employee("empl1", "1234");
	}


	/**
	 * Test method for {@link medical.com.medicalApplication.model.Employee#getName()}.
	 */
	@Test
	public void testGetName() {
		assertEquals("empl1", employee.getName());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Employee#getId()}.
	 */
	@Test
	public void testGetId() {
		assertEquals("1234", employee.getId());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Employee#getPassword()}.
	 */
	@Test
	public void testGetPassword() {
		assertEquals("Open", employee.getPassword());
	}

}

package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PatientTest {

	Patient patient;
	
	@Before
	public void setUp() throws Exception {
		patient = new Patient("patient1", "pat1234");
	}

	@Test
	public void testGetName() {
		assertEquals("patient1", patient.getName());
	}

	@Test
	public void testSetName() {
		patient.setName("patient2");
		assertEquals("patient2", patient.getName());
	}

	@Test
	public void testGetId() {
		assertEquals("pat1234", patient.getId());
	}

	@Test
	public void testSetId() {
		patient.setId("pat5678");
		assertEquals("pat5678", patient.getId());
	}

	@Test
	public void testToString() {
		assertEquals("Patient Name: patient1 ID: pat1234", patient.toString());
	}

}

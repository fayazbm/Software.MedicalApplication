/**
 * 
 */
package medical.com.medicalApplication.services;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;

public class AllergeyFindTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.MedicalRescordService#getPatientsWithAllergies(java.lang.String)}.
	 */
	
	@Test
	public void testGetPatientsWithAllergies() {
		//Medical record of a patient with peanuts allergey
		MedicalRescordService.getReference().addPatient("patientWithPeanutAllergey", "pat1234");
		Allergey peanutAllergey = new Allergey("peanuts");
		MedicalRescordService.getReference().getMedicalRecord("pat1234").getHistory().addAllergy(peanutAllergey);
		
		//Medical record of a patient with eggs allergey
		MedicalRescordService.getReference().addPatient("patientWithEggAllergey", "pat5678");
		Allergey eggsAllergey = new Allergey("eggs");
		MedicalRescordService.getReference().getMedicalRecord("pat5678").getHistory().addAllergy(eggsAllergey);
		
		assertEquals(1, MedicalRescordService.getReference().getPatientsWithAllergies("peanuts").size());
		assertEquals("patientWithPeanutAllergey",  MedicalRescordService.getReference().getPatientsWithAllergies("peanuts").get(0).getName());
		
		assertEquals(1, MedicalRescordService.getReference().getPatientsWithAllergies("eggs").size());
		assertEquals("patientWithEggAllergey", MedicalRescordService.getReference().getPatientsWithAllergies("eggs").get(0).getName());
		
		
	}

}

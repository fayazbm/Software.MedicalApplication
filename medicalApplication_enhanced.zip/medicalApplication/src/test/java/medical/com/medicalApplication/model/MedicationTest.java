/**
 * 
 */
package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * @author kohliastha1
 *
 */
public class MedicationTest {

	Medication medication;
	
	/**
	 * @throws java.lang.Exception
	 */
	
	
	@Before
	public void setUp() throws Exception {
		 medication = new Medication("med1", "01/15/2019", "02/05/2019", "dose1");
	}


	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#getName()}.
	 */
	@Test
	public void testGetName() {
		assertEquals("med1", medication.getName());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#setName(java.lang.String)}.
	 */
	@Test
	public void testSetName() {
		medication.setName("med2");
		assertEquals("med2", medication.getName());
	}

	@Test
	public void testSetNullName() {
		medication.setName(null);
		assertEquals(null, medication.getName());
	}
	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#getStartDate()}.
	 */
	@Test
	public void testGetStartDate() {
		assertEquals("01/15/2019", medication.getStartDate());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#setStartDate(java.lang.String)}.
	 */
	@Test
	public void testSetStartDate() {
		medication.setStartDate("01/20/2019");
		assertEquals("01/20/2019", medication.getStartDate());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#getEndDate()}.
	 */
	@Test
	public void testGetEndDate() {
		assertEquals("02/05/2019", medication.getEndDate());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#setEndDate(java.lang.String)}.
	 */
	@Test
	public void testSetEndDate() {
		medication.setEndDate("02/15/2019");
		assertEquals("02/15/2019", medication.getEndDate());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#getDose()}.
	 */
	@Test
	public void testGetDose() {
		assertEquals("dose1", medication.getDose());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#setDose(java.lang.String)}.
	 */
	@Test
	public void testSetDose() {
		medication.setDose("dose2");
		assertEquals("dose2", medication.getDose());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Medication#toString()}.
	 */
	@Test
	public void testToString() {
		assertEquals("Medication:med1 Start Date: 01/15/2019 End Date: 02/05/2019 Dose: dose1", medication.toString());
	}

}

package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AllergeyTest {

	/**
	 * @throws java.lang.Exception
	 */
	Allergey allergey ;
	
	@Before
	public void setUp() throws Exception {
		allergey = new Allergey("allergey1"); 
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Allergey#getName()}.
	 */
	@Test
	public void testGetName() {
		assertEquals("allergey1", allergey.getName());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Allergey#setName(java.lang.String)}.
	 */
	@Test
	public void testSetName() {
		allergey.setName("allergey2");
		assertEquals("allergey2", allergey.getName());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Allergey#toString()}.
	 */
	@Test
	public void testToString() {
		assertEquals("Allergy allergey1", allergey.toString());
	}

}

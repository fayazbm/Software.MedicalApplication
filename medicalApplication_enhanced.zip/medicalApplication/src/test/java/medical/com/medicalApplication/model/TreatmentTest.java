/**
 * 
 */
package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TreatmentTest {

	Treatment treatment ;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		treatment = new Treatment("02/05/2019", "diagnose1", "desc1");
	}


	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#getTreatmentDate()}.
	 */
	@Test
	public void testGetTreatmentDate() {
		assertEquals("02/05/2019", treatment.getTreatmentDate());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#setTreatmentDate(java.lang.String)}.
	 */
	@Test
	public void testSetTreatmentDate() {
		treatment.setTreatmentDate("02/15/2019");
		assertEquals("02/15/2019", treatment.getTreatmentDate());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#getDiagnose()}.
	 */
	@Test
	public void testGetDiagnose() {
		assertEquals("diagnose1", treatment.getDiagnose());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#setDiagnose(java.lang.String)}.
	 */
	@Test
	public void testSetDiagnose() {
		treatment.setDiagnose("diagnose2");
		assertEquals("diagnose2", treatment.getDiagnose());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#getDescription()}.
	 */
	@Test
	public void testGetDescription() {
		assertEquals("desc1", treatment.getDescription());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#setDescription(java.lang.String)}.
	 */
	@Test
	public void testSetDescription() {
		treatment.setDescription("desc2");
		assertEquals("desc2", treatment.getDescription());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.model.Treatment#toString()}.
	 */
	@Test
	public void testToString() {
		assertEquals("Treatment:  Date: 02/05/2019 Diagnose: diagnose1", treatment.toString());
	}

}

/**
 * 
 */
package medical.com.medicalApplication.services;

import static org.junit.Assert.*;

import org.junit.Test;

import medical.com.medicalApplication.model.Doctor;



public class DoctorServiceTest {

	
	/**
	 * Test method for {@link medical.com.medicalApplication.services.DoctorService#getReference()}.
	 */
	@Test
	public void testGetReference() {
		assertNotNull( DoctorService.getReference());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.DoctorService#getAllDoctors()}.
	 */
	@Test
	public void testGetAllDoctors() {
		assertNotNull(DoctorService.getReference().getAllDoctors());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.DoctorService#addDoctor(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testAddDoctor() {
		DoctorService.getReference().addDoctor("doc1", "doc1234");
		assertFalse(DoctorService.getReference().getAllDoctors().isEmpty());
		assertTrue(DoctorService.getReference().getAllDoctors().size()>0);	
		
		
		Doctor doc = DoctorService.getReference().getAllDoctors().stream().filter(entry -> "doc1".equals(entry.getName())).findAny().orElse(null); 
		assertNotNull(doc);
		assertEquals("doc1", doc.getName());	
	}
	@Test
	public void testAddDuplicateDoctor() {
		assertEquals(true, DoctorService.getReference().addDoctor("Bob", "12345"));
        assertFalse(!DoctorService.getReference().addDoctor("Mike", "12345"));

	}
	
	@Test(expected = NullPointerException.class)
	public void testAddNullDoctor() {
		DoctorService.getReference().addDoctor(null, null);
	}
}

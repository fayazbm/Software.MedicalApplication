/**
 * 
 */
package medical.com.medicalApplication.services;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.Treatment;

/**
 * @author kohliastha1
 *
 */
public class MedicalRecordTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.MedicalRescordService#getReference()}.
	 */
	@Test
	public void testGetReference() {
		assertNotNull( MedicalRescordService.getReference());
	}

	
	/**
	 * Test method for {@link medical.com.medicalApplication.services.MedicalRescordService#addPatient(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testAddPatient() {
		MedicalRescordService.getReference().addPatient("patient1", "pat1");
		assertFalse(MedicalRescordService.getReference().getAllPatients().isEmpty());
		assertTrue(MedicalRescordService.getReference().getAllPatients().size()>0);	
		Patient patient = MedicalRescordService.getReference().getAllPatients().stream().filter(entry -> "patient1".equals(entry.getName())).findAny().orElse(null); 
		assertNotNull(patient);
		assertEquals("patient1", patient.getName());
	}

	@Test
	public void testAddDuplicatePatient() {
		assertEquals(true, MedicalRescordService.getReference().addPatient("Mary", "12345"));
        assertFalse(MedicalRescordService.getReference().addPatient("Joeseph", "12345"));

	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.MedicalRescordService#getMedicalRecord(java.lang.String)}.
	 */
	@Test
	public void testGetMedicalRecord() {
		MedicalRescordService.getReference().addPatient("patient1", "pat1");
		assertEquals("patient1", MedicalRescordService.getReference().getMedicalRecord("pat1").getPatient().getName());	
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.MedicalRescordService#getPatient(java.lang.String)}.
	 */
	@Test
	public void testGetPatient() {
		MedicalRescordService.getReference().addPatient("patient1", "pat1");
		assertEquals("patient1",MedicalRescordService.getReference().getPatient("pat1").getName());
	}

	/**
	 * Test method for {@link medical.com.medicalApplication.services.MedicalRescordService#getAllPatients()}.
	 */
	@Test
	public void testGetAllPatients() {
		MedicalRescordService.getReference().addPatient("patient1", "pat1");
		
		assertTrue(MedicalRescordService.getReference().getAllPatients().size()>0);	
		Patient patient = MedicalRescordService.getReference().getAllPatients().stream().filter(entry -> "patient1".equals(entry.getName())).findAny().orElse(null); 
		assertNotNull(patient);
		assertEquals("patient1", patient.getName());
		assertEquals("pat1", patient.getId());
		
	}
	
	

	@Test(expected = Test.None.class)
	public void testAddPatientWithTreatmentAllergyMedication() {
		//Medical record of a patient with peanuts allergey
		MedicalRescordService.getReference().addPatient("patientWithSoyAllergey", "4444");
		Allergey soyAllergey = new Allergey("Soy");
		Treatment soyTreatment = new Treatment("01/15/2019", "Soy diagnose", "Soy treatment");
		Medication soyMedication = new Medication("Soy medication", "01/15/2019", "01/30/2019", "twice");
		
		//This makes sure, no exceptions thrown while adding Treatment, Medication, Allergey in order
		MedicalRescordService.getReference().getMedicalRecord("4444").getHistory().addTreatment(soyTreatment);
		MedicalRescordService.getReference().getMedicalRecord("4444").getHistory().addMedication(soyMedication);
		MedicalRescordService.getReference().getMedicalRecord("4444").getHistory().addAllergy(soyAllergey);
		
	}
	
	@Test
	public void testAddMedicationWithoutTreatment() {
		//Medical record of a patient with peanuts allergey
		MedicalRescordService.getReference().addPatient("patientWithNutsAllergey", "5555");
		Allergey nutsAllergey = new Allergey("Nuts");
		Medication nutsMedication = new Medication("Nuts medication", "01/15/2019", "01/30/2019", "twice");
		
		//This makes sure, no medication should be added until patient has a treatment
		assertTrue(MedicalRescordService.getReference().getMedicalRecord("5555").getHistory().getAllTreatments().isEmpty());
		MedicalRescordService.getReference().getMedicalRecord("5555").getHistory().addMedication(nutsMedication);
		assertTrue(MedicalRescordService.getReference().getMedicalRecord("5555").getHistory().getAllMedications().isEmpty());
		
	}
	
}
